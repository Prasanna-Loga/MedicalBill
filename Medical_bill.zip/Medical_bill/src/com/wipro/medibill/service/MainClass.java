package com.wipro.medibill.service;

import com.wipro.medibill.bean.RequestBean;
import com.wipro.medibill.dao.BillDAO;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BillDAO b=new BillDAO();
		RequestBean bean=new RequestBean();
		bean.setItemRequested(1002);
		bean.setQtyRequested(2);
		System.out.println(b.generateBill(bean));
		
	}

}
