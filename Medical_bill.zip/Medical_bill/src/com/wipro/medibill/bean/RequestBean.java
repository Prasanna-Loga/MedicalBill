package com.wipro.medibill.bean;

public class RequestBean {
	private int itemRequested;
	private int qtyRequested;
	public int getItemRequested() {
		return itemRequested;
	}
	public void setItemRequested(int itemRequested) {
		this.itemRequested = itemRequested;
	}
	public int getQtyRequested() {
		return qtyRequested;
	}
	public void setQtyRequested(int qtyRequested) {
		this.qtyRequested = qtyRequested;
	}
}
