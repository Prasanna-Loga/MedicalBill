package com.wipro.medibill.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.wipro.medibill.bean.RequestBean;
import com.wipro.medibill.util.DBUtil;
import com.wipro.medibill.util.InvalidInputException;

public class BillDAO {
	Connection con;
	Statement stmt;
	ResultSet rs;
	public String getRequest(RequestBean rBean) {
		if(!((rBean.getItemRequested()>1000&&rBean.getItemRequested()<=5000)&&(""+rBean.getItemRequested()).matches("[0-9]+"))||rBean.getQtyRequested()<0)
		{
		try {
				throw new InvalidInputException();
				}
				catch (InvalidInputException e) {
					return e.toString();
				}
			}
		return "success";
	}
	public boolean	getStockAvailability(RequestBean reqbean)
	{
		if(getRequest(reqbean)=="success");
		{
			DBUtil db = new DBUtil();
			try {
				 con = db.getConnectivity();
				 //System.out.println("Connected database successfully...");
				stmt = con.createStatement();
				 //System.out.println("Creating statement...");
				String query="select qtyInStock from MediBill_Source where itemID="+reqbean.getItemRequested();
				rs = stmt.executeQuery(query);
				while(rs.next()) {
				System.out.println("Available stock :"+rs.getInt(1));
				System.out.println("Required count of medicine:"+reqbean.getQtyRequested());
				if(rs.getInt(1)>=reqbean.getQtyRequested())
					return true;
				} 
			}
			catch (SQLException e) {
				e.printStackTrace();
				}
		}
		return false;
	}
	public String generateBill (RequestBean reqbean)
	{
		if(getRequest(reqbean)!="success")
		return getRequest(reqbean);
		boolean t=getStockAvailability(reqbean);
		if(t==true)
			{
			DBUtil db = new DBUtil();
			try {
			float Amount;
			con = db.getConnectivity();
			stmt = con.createStatement();
			String query="select unitPrice,itemName,qtyInStock from MediBill_Source where itemID="+reqbean.getItemRequested();
			//System.out.println("chk2");
			rs = stmt.executeQuery(query);
			rs.next();
			//System.out.println(rs.getFloat(1));
			Amount=rs.getFloat(1)*reqbean.getQtyRequested();
			String name=rs.getString(2);
			
			String query1="UPDATE MediBill_Source SET qtyInStock = qtyInStock-"+reqbean.getQtyRequested()+" WHERE itemID="+reqbean.getItemRequested();
			stmt.executeUpdate(query1);
			rs=stmt.executeQuery(query);
			rs.next();
			
			System.out.println("updated stock: "+rs.getInt(3));
			return reqbean.getItemRequested()+":"+name+":"+Amount;
				}
			catch (SQLException e) {
				e.printStackTrace();
				}
			}
		else if(t==false)
			return "Stock Not Available:"+reqbean.getItemRequested();
		else
		return getRequest(reqbean);
		return null;
		}
}
